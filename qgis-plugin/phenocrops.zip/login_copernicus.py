from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QDialog, QFileDialog, QMessageBox
from .login_copernicus_ui import Ui_Dialog

# Imports
import requests
import geopandas as gpd
from shapely.geometry import box
import os
import time
import webbrowser
import numpy as np
import datetime
import json

# Functions to interact with CDSE API
def _get_keycloak_token(username, password):
    
    # Obtaining the access token to Copernicus Data Space Ecosystem.
    token_url = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
    payload = {
        "client_id": "cdse-public",
        "username": username,
        "password": password,
        "grant_type": "password",
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded"
    }

    try:
        response = requests.post(token_url, data=payload, headers=headers)
        response.raise_for_status()  # Levanta um HTTPError para 4xx/5xx respostas
        return response.json()["access_token"]
    except requests.exceptions.HTTPError as http_err:
        if response.status_code == 400:
            error_details = http_err.response.json().get("error_description", "Unknown authentication error.")
            raise Exception(f"Authentication error (HTTP 400): {error_details}") from http_err
        raise Exception(f"HTTP error while obtaining token: {http_err} - {http_err.response.text}") from http_err
    except requests.exceptions.ConnectionError as conn_err:
        raise Exception(f"Connection error while obtaining token: Check your internet connection or firewall. {conn_err}") from conn_err
    except requests.exceptions.Timeout as timeout_err:
        raise Exception(f"Timeout while obtaining token: The server took too long to respond. {timeout_err}") from timeout_err
    except Exception as err:
        raise Exception(f"Unexpected error while obtaining token: {err}") from err

class DownloadThread(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self, username, password, bbox, start_date, end_date, output_folder):
        super().__init__()
        self.username = username
        self.password = password
        self.bbox = bbox
        self.start_date = start_date
        self.end_date = end_date
        self.cloud_cover = 10
        self.output_folder = output_folder
        self.access_token = None # just on the start function

    def run(self):
        try:
            # Obtain the authentication token
            self.access_token = _get_keycloak_token(self.username, self.password)
            
            # Create a requests session
            session = requests.Session()
            session.headers.update({
                "Authorization": f"Bearer {self.access_token}",
                "Accept": "application/json"
            })

            # Build the footprint in WKT from the bbox (already in WGS 84).
            footprint_wkt = f"POLYGON(({self.bbox[0]} {self.bbox[1]}, {self.bbox[2]} {self.bbox[1]}, {self.bbox[2]} {self.bbox[3]}, {self.bbox[0]} {self.bbox[3]}, {self.bbox[0]} {self.bbox[1]}))" # shape of bbox: [min_lon, min_lat, max_lon, max_lat]
            
            # Build the query URL for the API
            start_date_iso = self.start_date.isoformat() + "T00:00:00.000Z" # The date must have the correct format
            end_date_iso = self.end_date.isoformat() + "T23:59:59.999Z"

            # Filter parameters
            query_filter = (
                f"Collection/Name eq 'SENTINEL-2' "
                f"and ContentDate/Start ge {start_date_iso} "
                f"and ContentDate/Start le {end_date_iso} "
                f"and OData.CSC.Intersects(area=geography'SRID=4326;{footprint_wkt}') "
                f"and contains(Name, 'MSIL2A') " # Filter to L2A product
                f"and Online eq true " # The whitespace in the end is mandatory
                f"and Attributes/OData.CSC.DoubleAttribute/any(att:att/Name eq 'cloudCover' and att/OData.CSC.DoubleAttribute/Value le {float(self.cloud_cover):.2f})" # Get images with cloud coverage less than or equal (le) 10%
            )
            
            search_url = (
                f"https://catalogue.dataspace.copernicus.eu/odata/v1/Products?"
                f"$filter={query_filter}&$top=100" # Limit for results (images) found
            )
            
            # Make the search request using the session (credentials login)
            search_response = session.get(search_url, timeout=(10, 30)) # timeout
            search_response.raise_for_status() # HTTP error
            
            products_data = search_response.json().get('value', [])

            # Filter again by the L2A product if the URL fail
            filtered_products_data = [
                p for p in products_data if p.get('Name', '').find('MSIL2A') != -1
            ]
            
            # Check if no data was found
            if not filtered_products_data:
                self.error.emit("No online Sentinel-2 L2A images found for the provided parameters. Try a longer time range or a different area.")
                return

            total_products = len(filtered_products_data) # Total of filtered products
            
            # Start the download of images found
            downloaded_count = 0
            for i, product_info in enumerate(filtered_products_data):
                product_id = product_info['Id']
                product_title = product_info['Name']
                
                download_url = f"https://download.dataspace.copernicus.eu/odata/v1/Products({product_id})/$value"
                
                # File name to save
                filename = os.path.join(self.output_folder, f"{product_title}.zip")

                self.progress.emit(int((downloaded_count / total_products) * 100)) # progress bar

                try:
                    # Make the download request using credentials
                    with session.get(download_url, headers=session.headers, stream=True, timeout=(30, 300)) as download_req: # headers
                        download_req.raise_for_status() # status errors
                        with open(filename, 'wb') as f:
                            for chunk in download_req.iter_content(chunk_size=8192):
                                f.write(chunk)
                    
                    downloaded_count += 1
                    self.progress.emit(int((downloaded_count / total_products) * 100)) # progress bar
                    
                except requests.exceptions.HTTPError as http_err:
                    if http_err.response.status_code == 401:
                        # Print error messages
                        error_details = http_err.response.text
                        self.error.emit(f"Error 401 – Unauthorized when downloading {product_title}: {error_details}. Check token permissions or whether the product is online. Continuing with other products.")
                    elif http_err.response.status_code == 404:
                        self.error.emit(f"Error 404 – Product {product_title} not found during download: {http_err}. It may be offline or moved. Continuing with other products.")
                    else:
                        self.error.emit(f"HTTP error ({http_err.response.status_code}) while downloading {product_title}: {http_err}. Continuing with other products.")
                except requests.exceptions.RequestException as req_err:
                    self.error.emit(f"Request error while downloading {product_title}: {req_err}. Please check your connection. Continuing with other products.")
                except Exception as dl_e:
                    self.error.emit(f"Unexpected error while downloading product {product_title}: {dl_e}. Continuing with other products.")
            
            if downloaded_count == 0 and total_products > 0:
                self.error.emit("No products were successfully downloaded, despite some products being found. Check the logs for more details.")
            elif downloaded_count > 0:
                self.finished.emit()
            else:
                self.finished.emit() # Close without error

        except Exception as e:
            # Catch errors
            self.error.emit(f"An error occurred during the download operation: {str(e)}")


class LoginCopernicusDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)

        self.ui.btnShp.clicked.connect(self.select_shapefile)
        self.ui.btnBrowse.clicked.connect(self.select_output_folder)
        self.ui.btnLogin.clicked.connect(self.download_images)
        self.ui.btnWebsite.clicked.connect(self.open_copernicus)
        self.ui.btnBack.clicked.connect(self.back)

    def select_shapefile(self):
        filename_tuple = QFileDialog.getOpenFileName(self, "Select Shapefile", "", "Shapefiles (*.shp)")
        if filename_tuple[0]:
            self.ui.lnShp.setText(filename_tuple[0])
        else:
            self.ui.lnShp.setText("")
            QMessageBox.warning(self, "Warning", "No sample file selected.")

    def select_output_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if folder:
            self.ui.lnOutput.setText(folder)

    def download_images(self):
        username = self.ui.lnUser.text()
        password = self.ui.lnPassword.text()
        shapefile_path = self.ui.lnShp.text()
        output_folder = self.ui.lnOutput.text()
        
        start_date_qdate = self.ui.dtInitial.date()
        end_date_qdate = self.ui.dtFinal.date()

        start_date_dt = datetime.date(start_date_qdate.year(), start_date_qdate.month(), start_date_qdate.day())
        end_date_dt = datetime.date(end_date_qdate.year(), end_date_qdate.month(), end_date_qdate.day())

        if not username or not password:
            QMessageBox.warning(self, "Login error", "Please enter your username and password for the Copernicus Data Space Ecosystem.")
            return
        if not shapefile_path:
            QMessageBox.warning(self, "Input error", "Please select a shapefile.")
            return
        if not output_folder:
            QMessageBox.warning(self, "Output error", "Please select an output folder.")
            return

        try:
            gdf = gpd.read_file(shapefile_path) # shapefile read
            
            # reproject to WGS 84 (EPSG:4326)
            if gdf.crs != 'EPSG:4326':
                gdf_wgs84 = gdf.to_crs(epsg=4326)
                bbox = gdf_wgs84.total_bounds
            else:
                bbox = gdf.total_bounds

            # Bounding box error
            if np.any(np.isnan(bbox)):
                QMessageBox.critical(self, "Bounding Box Error", "Could not calculate a valid bounding box for the shapefile. Please check if it contains valid geometries and a correct CRS.")
                return

        except Exception as e:
            QMessageBox.critical(self, "Shapefile error", f"Error reading or reprojecting the shapefile:\n{str(e)}")
            return

        self.ui.btnLogin.setEnabled(False) # Disable the download button

        self.thread = DownloadThread(username, password, bbox, start_date_dt, end_date_dt, output_folder)
        self.thread.progress.connect(self.ui.progressDownload.setValue)
        self.thread.finished.connect(self.download_finished)
        self.thread.error.connect(self.download_error)
        self.thread.start() # Start the thread

    def download_finished(self):
        QMessageBox.information(self, "Download", "Download completed successfully.")
        self.ui.btnLogin.setEnabled(True)
        self.ui.progressDownload.setValue(0)

    def download_error(self, message):
        QMessageBox.critical(self, "Download error", message)
        self.ui.btnLogin.setEnabled(True)
        self.ui.progressDownload.setValue(0)

    def open_copernicus(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Important warning")
        msg.setText("To use this tool, you need to download Sentinel-2 sensor images at Level L2A.")
        
        msg.setStandardButtons(QMessageBox.Ok)
        ok_button = msg.button(QMessageBox.Ok)
        ok_button.setText("Continue")
        
        ret = msg.exec_()
        # Open the website manually (button)
        if ret == QMessageBox.Ok:
            url = "https://browser.dataspace.copernicus.eu/?zoom=5&lat=50.16282&lng=20.78613&demSource3D=%22MAPZEN%22&cloudCoverage=30&dateMode=SINGLE"
            webbrowser.open(url)

    def back(self):
        self.close()
        if self.parent():
            self.parent().show() # Show the main window
