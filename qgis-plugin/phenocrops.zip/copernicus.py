from qgis.PyQt.QtWidgets import QDialog, QFileDialog, QMessageBox
from .login_copernicus_ui import Ui_Dialog  # arquivo gerado pelo pyuic5

class LoginCopernicusDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)

        # Conectar botões
        self.ui.btnLogin.clicked.connect(self.download_images)
        self.ui.btnBack.clicked.connect(self.close)
        self.ui.btnWebsite.clicked.connect(self.open_website)
        self.ui.btnShp.clicked.connect(self.select_shapefile)
        self.ui.btnBrowse.clicked.connect(self.select_output_folder)

    def download_images(self):
        username = self.ui.lnUser.text()
        password = self.ui.lnPassword.text()
        shapefile_path = self.ui.lnShp.text()
        output_folder = self.ui.lnOutput.text()
        start_date = self.ui.dtInitial.date().toString("yyyy-MM-dd")
        end_date = self.ui.dtFinal.date().toString("yyyy-MM-dd")

        if not username or not password:
            QMessageBox.warning(self, "Login error", "Please enter your username and password.")
            return
        if not shapefile_path:
            QMessageBox.warning(self, "Input error", "Please select a shapefile.")
            return
        if not output_folder:
            QMessageBox.warning(self, "Output error", "Please select an output folder.")
            return
        
        # Search and download images
        QMessageBox.information(self, "Download", "Download started (exemplo).")

    def select_shapefile(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Select shapefile", "", "Shapefiles (*.shp)")
        if filename:
            self.ui.lnShp.setText(filename)

    def select_output_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select output folder")
        if folder:
            self.ui.lnOutput.setText(folder)

    def open_website(self):
        import webbrowser
        webbrowser.open("https://scihub.copernicus.eu/")
